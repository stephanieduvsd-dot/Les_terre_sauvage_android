const c=document.getElementById("canvas"),ctx=c.getContext("2d");
let W,H,scale=1,started=false,keys={},last=0,attackCD=0,wood=0,stone=0,xp=0,hp=100;
const tile=48, world={w:1800,h:1200};
const player={x:900,y:600,r:18,s:3.1,dir:{x:1,y:0}};
let enemies=[],resources=[],buildings=[];
let inventory={potion:2,iron:0}, weapon="sword";
let quest={kills:0,need:3,done:false}, bossSpawned=false;
function resize(){W=c.clientWidth;H=c.clientHeight;scale=Math.min(W/world.w,H/world.h);c.width=W*devicePixelRatio;c.height=H*devicePixelRatio;ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0)}addEventListener("resize",resize);resize();
function rand(a,b){return a+Math.random()*(b-a)}
function reset(){
 inventory={potion:2,iron:0}; weapon="sword"; quest={kills:0,need:3,done:false}; bossSpawned=false;
 hp=100;wood=0;stone=0;xp=0;player.x=900;player.y=600;buildings=[];resources=[];enemies=[];
 for(let i=0;i<65;i++) resources.push({x:rand(50,1750),y:rand(50,1150),t:Math.random()<.65?"tree":"rock",r:16});
 for(let i=0;i<12;i++){let type=Math.random()<.2?"archer":"goblin";
enemies.push({x:rand(100,1700),y:rand(100,1100),r:type==="archer"?15:17,hp:type==="archer"?30:40,cd:0,type})}
 msg("Explore la carte. Ramasse du bois et de la pierre, puis construis ta maison !");
}

function saveGame(){
  const data={hp,wood,stone,xp,player:{x:player.x,y:player.y},inventory,weapon,quest,bossSpawned,
    buildings,resources,enemies:enemies.map(e=>({x:e.x,y:e.y,r:e.r,hp:e.hp,cd:e.cd,type:e.type}))};
  localStorage.setItem("terres_sauvages_save",JSON.stringify(data));
  msg("💾 Partie sauvegardée !");
}
function loadGame(){
  const raw=localStorage.getItem("terres_sauvages_save");
  if(!raw){msg("Aucune sauvegarde trouvée.");return false}
  try{
    const d=JSON.parse(raw);
    hp=d.hp??100;wood=d.wood??0;stone=d.stone??0;xp=d.xp??0;
    player.x=d.player?.x??900;player.y=d.player?.y??600;
    inventory=d.inventory??{potion:2,iron:0};weapon=d.weapon??"sword";
    quest=d.quest??{kills:0,need:3,done:false};bossSpawned=!!d.bossSpawned;
    buildings=d.buildings??[];resources=d.resources??[];enemies=d.enemies??[];
    started=true;document.getElementById("menu").style.display="none";updateHud();
    msg("📂 Sauvegarde chargée !");
    return true;
  }catch(e){msg("Sauvegarde invalide.");return false}
}
function autoSave(){if(started)localStorage.setItem("terres_sauvages_save",JSON.stringify({
  hp,wood,stone,xp,player:{x:player.x,y:player.y},inventory,weapon,quest,bossSpawned,buildings,resources,enemies
}))}
setInterval(autoSave,15000);

function msg(t){document.getElementById("msg").textContent=t;clearTimeout(msg.t);msg.t=setTimeout(()=>document.getElementById("msg").textContent="",3200)}
function updateHud(){hp=Math.max(0,hp);document.getElementById("hp").textContent=Math.round(hp);document.getElementById("wood").textContent=wood;document.getElementById("stone").textContent=stone;document.getElementById("xp").textContent=xp}
function nearestEnemy(){let best=null,d=1e9;for(const e of enemies){let q=Math.hypot(e.x-player.x,e.y-player.y);if(q<d){d=q;best=e}}return [best,d]}
function attack(){if(!started||attackCD>0)return;attackCD=.35;let [e,d]=nearestEnemy();if(e&&d<90){e.hp-=25;msg("⚔️ Coup porté !");if(e.hp<=0){
 xp+=10;wood+=2;stone+=1;quest.kills++;enemies=enemies.filter(x=>x!==e);
 msg("Monstre vaincu ! +10 XP");
 if(quest.kills>=quest.need&&!quest.done){quest.done=true;inventory.iron+=3;inventory.potion+=2;msg("🎁 Quête terminée !")}
 if(xp>=80&&!bossSpawned){bossSpawned=true;enemies.push({x:player.x+220,y:player.y,r:32,hp:180,cd:0,type:"boss"});msg("👑 LE GARDIEN apparaît !")}
}}}
function collect(){for(const r of resources){let d=Math.hypot(r.x-player.x,r.y-player.y);if(d<55){if(r.t==="tree")wood+=3;else stone+=2;resources=resources.filter(x=>x!==r);msg(r.t==="tree"?"🪵 Bois récolté !":"🪨 Pierre récoltée !");return}}msg("Approche-toi d'un arbre ou d'un rocher.")}
function usePotion(){if(inventory.potion>0&&hp<100){inventory.potion--;hp=Math.min(100,hp+35);msg("🧪 Potion utilisée !");updateHud()}}
function switchWeapon(){weapon=weapon==="sword"?"axe":weapon==="axe"?"spear":"sword";msg("Arme : "+weapon)}
function build(type){if(!started)return;let cost={wall:5,floor:3,door:4}[type];if(wood<cost){msg("Pas assez de bois.");return}wood-=cost;buildings.push({x:Math.round((player.x)/tile)*tile,y:Math.round((player.y)/tile)*tile,t:type});msg("🏠 Construction ajoutée !");}
function move(dt){
 let x=0,y=0;if(keys.ArrowLeft||keys.a)x--;if(keys.ArrowRight||keys.d)x++;if(keys.ArrowUp||keys.w)y--;if(keys.ArrowDown||keys.s)y++;
 if(x||y){let l=Math.hypot(x,y);x/=l;y/=l;player.dir={x,y};player.x+=x*player.s*60*dt;player.y+=y*player.s*60*dt}
 player.x=Math.max(25,Math.min(world.w-25,player.x));player.y=Math.max(25,Math.min(world.h-25,player.y));
 for(const e of enemies){let dx=player.x-e.x,dy=player.y-e.y,d=Math.hypot(dx,dy);if(d<260&&d>38){e.x+=dx/d*35*dt;e.y+=dy/d*35*dt}if(d<42&&e.cd<=0){hp-=e.type==="boss"?18:8;e.cd=e.type==="boss"?0.8:1.1;msg("💥 Un monstre t'a touché !")}
if(e.type==="archer"&&d<300&&d>100&&e.cd<=0){hp-=5;e.cd=1.7;msg("🏹 Une flèche t'atteint !")}
if(e.type==="boss"&&e.hp<=0){xp+=100;msg("🏆 GARDIEN VAINCU !");e.hp=-1}e.cd-=dt}
 attackCD=Math.max(0,attackCD-dt);updateHud();
 if(hp<=0){msg("Tu es tombé au combat… Appuie sur Jouer pour recommencer.");started=false;document.getElementById("menu").style.display="flex"}
}
function draw(){
 ctx.clearRect(0,0,W,H);let camX=player.x-W/2,camY=player.y-H/2;
 ctx.save();ctx.translate(-camX,-camY);
 ctx.fillStyle="#3f7040";ctx.fillRect(0,0,world.w,world.h);
 for(let x=0;x<world.w;x+=tile)for(let y=0;y<world.h;y+=tile){ctx.fillStyle=((x/tile+y/tile)%2?"#427344":"#467a48");ctx.fillRect(x,y,tile,tile)}
 for(const r of resources){if(r.t==="tree"){ctx.fillStyle="#704728";ctx.fillRect(r.x-5,r.y,10,23);ctx.fillStyle="#1d5c32";ctx.beginPath();ctx.arc(r.x,r.y,22,0,7);ctx.fill();ctx.fillStyle="#28733d";ctx.beginPath();ctx.arc(r.x-12,r.y+2,14,0,7);ctx.fill()}else{ctx.fillStyle="#8b8f8a";ctx.beginPath();ctx.arc(r.x,r.y,16,0,7);ctx.fill();ctx.fillStyle="#b6bbb4";ctx.beginPath();ctx.arc(r.x-5,r.y-5,7,0,7);ctx.fill()}}
 for(const b of buildings){ctx.fillStyle=b.t==="floor"?"#a87843":b.t==="door"?"#7a4c2a":"#d0b06b";ctx.fillRect(b.x-22,b.y-22,44,44);if(b.t==="wall"){ctx.strokeStyle="#684c2d";ctx.lineWidth=4;ctx.strokeRect(b.x-22,b.y-22,44,44)}if(b.t==="door"){ctx.fillStyle="#4a2b1c";ctx.fillRect(b.x-8,b.y-18,16,36)}}
 for(const e of enemies){ctx.fillStyle=e.type==="boss"?"#8e1d1d":e.type==="archer"?"#4c4c86":"#642e68";
ctx.beginPath();ctx.arc(e.x,e.y,e.r,0,7);ctx.fill();ctx.fillStyle="#fff";ctx.fillRect(e.x-9,e.y-5,5,5);ctx.fillRect(e.x+4,e.y-5,5,5);ctx.fillStyle="#e44";ctx.fillRect(e.x-20,e.y-28,40,5);ctx.fillStyle="#5f5";ctx.fillRect(e.x-20,e.y-28,40*(e.hp/40),5)}
 ctx.fillStyle="#2771d1";ctx.beginPath();ctx.arc(player.x,player.y,player.r,0,7);ctx.fill();ctx.fillStyle="#ffe0b0";ctx.beginPath();ctx.arc(player.x,player.y-19,10,0,7);ctx.fill();ctx.strokeStyle="#fff";ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(player.x,player.y);ctx.lineTo(player.x+player.dir.x*28,player.y+player.dir.y*28);ctx.stroke();
 ctx.restore();
}
function loop(t){let dt=Math.min(.05,(t-last)/1000||0);last=t;if(started)move(dt);draw();requestAnimationFrame(loop)}requestAnimationFrame(loop);
addEventListener("keydown",e=>{keys[e.key]=true;if(e.key===" "||e.key==="j")attack();if(e.key==="e")collect();if(e.key==="q")usePotion();if(e.key==="r")switchWeapon();if(e.key==="b")document.getElementById("buildbar").classList.toggle("show")});
addEventListener("keyup",e=>keys[e.key]=false);
document.querySelectorAll("[data-key]").forEach(b=>{b.onpointerdown=()=>keys[b.dataset.key]=true;b.onpointerup=b.onpointercancel=()=>keys[b.dataset.key]=false});
document.getElementById("attack").onclick=attack;document.getElementById("interact").onclick=collect;document.getElementById("build").onclick=()=>document.getElementById("buildbar").classList.toggle("show");
document.querySelectorAll("[data-build]").forEach(b=>b.onclick=()=>build(b.dataset.build));
document.getElementById("save").onclick=saveGame;
document.getElementById("load").onclick=loadGame;
document.getElementById("start").onclick=()=>{document.getElementById("menu").style.display="none";started=true;reset()};
if("serviceWorker" in navigator)navigator.serviceWorker.register("sw.js");
